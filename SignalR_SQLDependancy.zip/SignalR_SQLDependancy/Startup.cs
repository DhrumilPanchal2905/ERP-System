using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using SignalR_SQLDependancy.Hubs;
using SignalR_SQLDependancy.ISubscribeTableDependencies;
using SignalR_SQLDependancy.SubscribeTableDependencies;
using SignalR_SqlTableDependency.MiddlewareExtensions;
using SignalR_SqlTableDependency.SubscribeTableDependencies;
using app = System.Configuration;







namespace SignalR_SQLDependancy
{
    public class Startup
    {
      

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
            

        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllersWithViews();
            services.AddSignalR(o =>
            {
                o.EnableDetailedErrors = true;
            });
            
            services.AddSingleton<DashboardHub>();
            services.AddSingleton<SubscribeProductTableDependency>();
            services.AddSingleton<SubscribeSaleTableDependency>();
            services.AddSingleton<SubscribeCustomerTableDependency>();
            services.ConfigureApplicationCookie(option => option.LoginPath = "/Identity/Account/Login");

            
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)

        {
            
            
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            { 
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            //app.UseProductTableDependency();
            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();
            


            


            app.UseEndpoints(endpoints =>
            {
                endpoints.MapRazorPages();

                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Dashboard}/{action=Index}/{id?}");


                endpoints.MapHub<DashboardHub>("/dashboardHub"); 
                 
            }); 
            
            
            
            
           
            

            app.UseSqlTableDependency<SubscribeProductTableDependency>("Data Source=WHAZ7237;Initial Catalog=Trainee_2022;User Id=sa;Password=Abc@1234;");
            app.UseSqlTableDependency<SubscribeSaleTableDependency>("Data Source=WHAZ7237;Initial Catalog=Trainee_2022;User Id=sa;Password=Abc@1234;");
            app.UseSqlTableDependency<SubscribeCustomerTableDependency>("Data Source=WHAZ7237;Initial Catalog=Trainee_2022;User Id=sa;Password=Abc@1234;");

           
           
        }
    }
}

  