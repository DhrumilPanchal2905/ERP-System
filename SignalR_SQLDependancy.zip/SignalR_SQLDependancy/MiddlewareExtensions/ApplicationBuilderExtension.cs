﻿
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Builder;
using SignalR_SqlTableDependency.SubscribeTableDependencies;
using Autofac.Core;
using System.Web.Services.Description;
using System;
using SignalR_SQLDependancy.SubscribeTableDependencies;
using SignalR_SQLDependancy.ISubscribeTableDependencies;

namespace SignalR_SqlTableDependency.MiddlewareExtensions
{
    public static class ApplicationBuilderExtension
    {
        public static void UseSqlTableDependency<T>(this IApplicationBuilder applicationBuilder, string connectionString)
            where T : ISubscribeTableDependency
        {
            var serviceProvider = applicationBuilder.ApplicationServices;
            var service = serviceProvider.GetService<T>();
            service.SubscribeTableDependency(connectionString);
            

        }
        
    }
}