﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace SignalR_SQLDependancy.Models
{
    public class CreateProductDB
    {
        SqlConnection con = new SqlConnection("Data Source=WHAZ7237;Initial Catalog=Trainee_2022;User Id=sa;Password=Abc@1234;");



        public string Saverecord(Product pro)
        {
            try
            {
                SqlCommand com = new SqlCommand("Sp_Product_Add", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("Name", pro.Name);
                com.Parameters.AddWithValue("Category", pro.Category);
                com.Parameters.AddWithValue("Price", pro.Price);
                con.Open();
                com.ExecuteNonQuery();
                con.Close();
                return ("ok");
            }
            catch (Exception ex)
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
                return (ex.Message.ToString());
            }
            
        }
    }




    
}
