﻿"use strict";
var connection = new signalR.HubConnectionBuilder().withUrl("/registration").build();

$(function () {
    connection.start().then(function () {

        alert('Registration connect');

    }).catch(function (err) { 
        return console.error(err.toString());
    });

});
